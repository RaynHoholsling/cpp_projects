#include <iostream>
using namespace std;

int main()
{
        float pie = 3.14f;
        int r;
        cin>> r;
        cout<<"Lenght of circle " << r*pie*2 <<endl;
        cout<<"Area of circle " << pie*r*r <<endl;
}

