#include <iostream> 
int main ()
{
	char a [100];
	std::cout<<"Enter Zeprezedent Name"<<std::endl;
	std::cin>>a;
	std::cout<<"Hello " << a <<std::endl;  
}
