#include <iostream>
int main()
{
	int a;
	int b;
	std::cin>> a;
	std::cin>> b;
	std::cout<<a+b<<std::endl;
	std::cout<<a-b<<std::endl;
	std::cout<<a*b<<std::endl;
}

